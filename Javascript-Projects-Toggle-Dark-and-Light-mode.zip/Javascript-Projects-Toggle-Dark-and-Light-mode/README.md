a light and dark toggling mode using html,css an javascript
